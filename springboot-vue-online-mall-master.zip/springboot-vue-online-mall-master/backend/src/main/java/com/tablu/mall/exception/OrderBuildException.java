package com.tablu.mall.exception;

public class OrderBuildException extends RuntimeException {

    public OrderBuildException(String message) {
        super(message);
    }
}
