package com.tablu.mall.pojo;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class UserRoleKey {

    private Integer uid;

    private Integer rid;

}