package com.tablu.mall.consts;

public class MallConst {

    public static final Integer CUSTOMER_ID = 1;
    public static final Integer EMPLOYEE_ID = 2;
    public static final Integer MANAGER_ID = 3;

    public static final Integer ROOT_CATEGORY_PARENT_ID = 0;
}
