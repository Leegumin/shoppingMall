// import Mock from 'mockjs'
// Mock.mock('/api/user/login',{
//     "status": 0,
//     "data": {
//         "id|10-20": 3,
//         "username": "@name",
//         "email": "saulgoodman@gmail.com",
//         "createTime": "Aug 20, 2020 7:32:28 AM",
//         "updateTime": "Aug 20, 2020 7:32:28 AM"
//     }
// });