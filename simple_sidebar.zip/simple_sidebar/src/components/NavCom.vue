<template>
<div>

</div>
</template>

<script>
import loadBar from '@/assets/js/scripts'
export default {
  name: "NavCom",
  data() {
    return {
    }
  },
  mounted() {
    loadBar();
  }
}
</script>

<style scoped>

</style>